import json
import configparser
from http.server import HTTPServer, BaseHTTPRequestHandler

# Function to parse the configuration file and store it in a dictionary
def parse_config(config_file):
    config = configparser.ConfigParser()
    config.read(config_file)
    parsed_data = {section: dict(config.items(section)) for section in config.sections()}
    return parsed_data

# Save the parsed data as JSON
config_data = parse_config("config.ini")
with open("config.json", "w") as json_file:
    json.dump(config_data, json_file, indent=4)

# Create a simple HTTP server to serve the configuration data
class ConfigHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "application/json")
        self.end_headers()

        with open("config.json", "rb") as json_file:
            self.wfile.write(json_file.read())

if __name__ == "__main__":
    httpd = HTTPServer(("localhost", 8000), ConfigHandler)
    print("Configuration File Parser Results:")
    for section, data in config_data.items():
        print(f"{section}:")
        for key, value in data.items():
            print(f"- {key}: {value}")
    print("Server is running at http://localhost:8000")
    httpd.serve_forever()
